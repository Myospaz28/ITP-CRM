import XLSX from "xlsx";
import { insertRawData, getRawData } from "../models/rawDataModel.js";
import db from "../database/db.js";




// export const importRawData = async (req, res) => {
//   try {
//     if (!req.session.user) {
//       return res.status(401).json({ message: 'Unauthorized. Please log in.' });
//     }

//     const file = req.file;
//     const { cat_id, reference, area_id } = req.body;
//     const created_by_user = req.session.user.id;

//     if (!file || !cat_id || !reference || !area_id || !created_by_user) {
//       return res.status(400).json({ message: "All fields are required!" });
//     }

//     const workbook = XLSX.read(file.buffer, { type: "buffer" });
//     const sheetName = workbook.SheetNames[0];
//     const data = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName]);

//     // const formattedData = data
//     //   .filter(row => row.name && row.contact && row.email && row.address)
//     //   .map(row => ({
//     //     name: row.name,
//     //     contact: row.contact,
//     //     email: row.email,
//     //     address: row.address,
//     //     area_id: area_id,
//     //     cat_id: cat_id,
//     //     reference_id: reference,
//     //     created_by_user: created_by_user
//     //   }));


//     const formattedData = data
//   .filter(row => row.name && row.contact && row.email && row.address)
//   .map(row => ({
//     name: row.name,
//     number: row.contact,   // ✅ FIXED
//     email: row.email,
//     address: row.address,
//     area_id: area_id,
//     cat_id: cat_id,
//     reference_id: reference,
//     created_by_user: created_by_user
//   }));


//     if (formattedData.length === 0) {
//       return res.status(400).json({ message: "No valid rows found in file." });
//     }

//     await insertRawData(formattedData);
//     res.status(200).json({ message: "Data imported successfully!" });

//   } catch (error) {
//     console.error("Error importing data:", error);
//     res.status(500).json({ message: "Server error while importing data." });
//   }
// };





// export const importRawData = async (req, res) => {
//   try {

//     if (!req.session.user) {
//       return res.status(401).json({ message: 'Unauthorized. Please log in.' });
//     }

//     const file = req.file;
//     const { cat_id, reference, area_id } = req.body;
//     const created_by_user = req.session?.user?.id;

//     if (!file || !cat_id || !reference || !area_id || !created_by_user) {
//       return res.status(400).json({ message: "All fields are required!" });
//     }

//     const workbook = XLSX.read(file.buffer, { type: "buffer" });
//     const sheetName = workbook.SheetNames[0];
//     const data = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName]);

//     console.log("logs : ");
//     console.log("File:", file.originalname);
//     console.log("cat_id:", cat_id);
//     console.log("reference:", reference);
//     console.log("area:", area_id);
//     console.log("created_by_user:", created_by_user);


//     const formattedData = data
//       .filter(row => row.name && row.contact && row.email && row.address)
//       .map(row => ({
//         name: row.name,
//         contact: row.contact,
//         email: row.email,
//         address: row.address,
//         area_id: area_id,
//         cat_id: cat_id,
//         reference_id: reference,
//         created_by_user: created_by_user
//       }));

//     if (formattedData.length === 0) {
//       return res.status(400).json({ message: "No valid rows found in file." });
//     }

//     await insertRawData(formattedData);
//     res.status(200).json({ message: "Data imported successfully!" });

//   } catch (error) {
//     console.error("Error importing data:", error);
//     res.status(500).json({ message: "Server error while importing data." });
//   }
// };


// fetch Master data controller 




// MAIN IMPORT CONTROLLER
export const importRawData = async (req, res) => {
  try {
    // CHECK LOGIN SESSION
    if (!req.session.user) {
      return res.status(401).json({ message: "Unauthorized. Please log in." });
    }

    const file = req.file;
    const { cat_id, reference, area_id } = req.body;
    const created_by_user = req.session.user.id;

    // VALIDATION
    if (!file || !cat_id || !reference || !area_id || !created_by_user) {
      return res.status(400).json({ message: "All fields are required!" });
    }

    // READ EXCEL FILE
    const workbook = XLSX.read(file.buffer, { type: "buffer" });
    const sheetName = workbook.SheetNames[0];
    const data = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName]);

    // FORMAT DATA
    const formattedData = data
      .filter(row => row.name && row.contact && row.email && row.address)
      .map(row => ({
        name: row.name,
        number: row.contact,
        email: row.email,
        address: row.address,
        area_id,
        cat_id,
        reference_id: reference,
        created_by_user
      }));

    if (formattedData.length === 0) {
      return res.status(400).json({ message: "No valid rows found in file." });
    }

    // STEP 1 — CHECK DUPLICATES
    for (let i = 0; i < formattedData.length; i++) {
      const row = formattedData[i];

      const [existing] = await db.query(
        `SELECT master_id FROM raw_data 
         WHERE email = ? OR number = ? LIMIT 1`,
        [row.email, row.number]
      );

      if (existing.length > 0) {
        return res.status(400).json({
          message: "Duplicate entries found",
          duplicates: [
            {
              row: i + 2,
              name: row.name,
              email: row.email,
              number: row.number || row.contact,
              issue: "Email or Contact already exists"
            }
          ]
        });

      }
    }

    // STEP 2 — INSERT INTO raw_data
    await insertRawData(formattedData);

    res.status(200).json({ message: "Data imported successfully!" });

  } catch (error) {
    console.error("Error importing data:", error);
    res.status(500).json({ message: "Server error while importing data." });
  }
};

export const getAllRawData = async (req, res) => {
  try {
    const raw_data = await getRawData();
    res.status(200).json(raw_data);
  } catch (error) {
    console.error('Error fetching Master Data:', error);
    res.status(500).json({ error: 'Failed to fetch Master Data' });
  }
};

// PUT /api/master-data/:master_id
// update controller
export const updateRawData = async (req, res) => {
  const master_id = req.params.master_id;
  console.log("master", master_id)

  const {
    name = null,
    number = null,
    email = null,
    address = null
  } = req.body;

  console.log("request body", req.body)

  if (!master_id) {
    return res.status(400).json({ message: 'master_id is required' });
  }

  try {
    const updateQuery = `
      UPDATE raw_data SET
        name = ?, number = ?, email = ?, address = ?
      WHERE master_id = ?
    `;

    const values = [name, number, email, address, master_id];

    console.log("data", values)

    const [result] = await db.execute(updateQuery, values);

    if (result.affectedRows === 0) {
      return res.status(404).json({ message: 'No matching record found to update' });
    }

    res.status(200).json({ message: 'Raw data updated successfully' });
  } catch (error) {
    console.error('Error updating raw_data:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
};



export const deleteClient = async (req, res) => {
  const { master_id } = req.params;

  try {
    await db.query('DELETE FROM raw_data WHERE master_id = ?', [master_id]);
    res.json({ message: 'Client deleted successfully' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Error deleting client' });
  }
};

// delete raw datat entries from raw data table
export const deleteMultipleClients = async (req, res) => {
  const { ids } = req.body; // Corrected: use req.body, not req.params

  if (!Array.isArray(ids) || ids.length === 0) {
    return res.status(400).json({ message: 'No client IDs provided' });
  }

  try {
    const placeholders = ids.map(() => '?').join(',');
    await db.query(`DELETE FROM raw_data WHERE master_id IN (${placeholders})`, ids);
    res.json({ message: 'Selected entries deleted successfully' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Error deleting the selected entries' });
  }
};

export const addSingleRawData = async (req, res) => {
  try {
    if (!req.session.user) {
      return res.status(401).json({ message: 'Unauthorized. Please log in.' });
    }

    const { name, contact, email, address, cat_id, reference, area_id } = req.body;
    const created_by_user = req.session.user.id;

    // VALIDATION
    if (!name || !contact || !email || !address || !cat_id || !reference || !area_id) {
      return res.status(400).json({ message: "All fields are required!" });
    }

    // CHECK EMAIL
    const [emailExists] = await db.query(
      'SELECT master_id FROM raw_data WHERE email = ?',
      [email]
    );

    // CHECK CONTACT (COLUMN NAME = number)
    const [contactExists] = await db.query(
      'SELECT master_id FROM raw_data WHERE number = ?',
      [contact]
    );

    // BOTH EXIST
    if (emailExists.length > 0 && contactExists.length > 0) {
      return res.status(409).json({
        message: "Duplicate entry found",
        duplicates: [
          {
            row: 1,
            name,
            email,
            number: contact,
            issue: "Email & Contact both exist"
          }
        ]
      });
    }

    // ONLY EMAIL
    if (emailExists.length > 0) {
      return res.status(409).json({
        message: "Duplicate entry found",
        duplicates: [
          {
            row: 1,
            name,
            email,
            number: contact,
            issue: "Email exists"
          }
        ]
      });
    }

    // ONLY CONTACT
    if (contactExists.length > 0) {
      return res.status(409).json({
        message: "Duplicate entry found",
        duplicates: [
          {
            row: 1,
            name,
            email,
            number: contact,
            issue: "Contact exists"
          }
        ]
      });
    }

    // INSERT PAYLOAD (IMPORTANT: CHANGE contact → number)
    const singleData = {
      name,
      number: contact,       // <<<< FIXED
      email,
      address,
      area_id,
      cat_id,
      reference_id: reference,
      created_by_user
    };

    await insertRawData([singleData]);

    res.status(200).json({ message: "Data added successfully!" });

  } catch (error) {
    console.error("Error adding single data:", error);
    res.status(500).json({ message: "Server error while adding data." });
  }
};